# 🕵️ Missão Impossível: Operação Crônica Codificada

Atenção, agentes. Temos um enigma literário e criptográfico em mãos. 

Um grande autor brasileiro escondeu o grande segredo de uma de suas célebres crônicas (a moral da história) em uma **imagem**. Para proteger essa informação de olhares interceptadores, ele ocultou a imagem **codificando-a convenientemente**. Além disso, para evitar que qualquer impostor se passe por ele, o autor **assinou a mensagem** para demonstrar e garantir sua autenticidade.

Sua missão, caso decida aceitá-la (e a recusa, obviamente, não é uma opção no plano de ensino), é decodificar essa imagem, extrair a moral da história e reportar ao nosso quartel-general.

Para que a operação seja bem-sucedida, o relatório final deverá ser submetido seguindo protocolos estritos de segurança:

1. A entrega será feita via **Pull Request (PR)**.
2. O seu PR deverá conter um **commit único** e este commit deve estar **obrigatoriamente assinado** (*signed commit*).
3. Na estrutura do projeto, crie uma pasta nomeada com o seu nome completo, em letras minúsculas e com as palavras separadas por *underline* (ex: `joao_da_silva_sauro`).
4. Dentro dessa pasta, deve haver um único arquivo chamado exatamente **`moral.md`**.
5. Neste arquivo, redija (utilizando a sintaxe Markdown) a moral da crônica conforme a sua investigação.

> *"Esta mensagem não se autodestruirá em 5 segundos, mas o relógio do repositório já está correndo e os merges não esperam por ninguém."*

Boa sorte, agente.